# Anonymous Message Website (বাংলা)

এই প্রজেক্টে ভিজিটররা নাম না দিয়ে মেসেজ পাঠাতে পারবে। পাবলিক পেজে সর্বশেষ ২০০টি মেসেজ সবাই দেখতে পারবে। `/admin` পেজে লগইন করে সর্বশেষ ৫০০টি মেসেজ দেখা ও মুছে ফেলা যাবে।

## 1) আগে যা লাগবে
- Python 3.11 বা নতুন
- অনলাইনে প্রকাশ করতে GitHub অ্যাকাউন্ট ও Render অ্যাকাউন্ট
- Admin-এর জন্য শক্তিশালী পাসওয়ার্ড

## 2) লোকাল কম্পিউটারে চালানো
টার্মিনাল/কমান্ড প্রম্পটে প্রজেক্ট ফোল্ডারে ঢুকে:

```bash
python -m venv .venv
```

Linux/macOS/Termux:
```bash
source .venv/bin/activate
pip install -r requirements.txt
```

Windows:
```bat
.venv\Scripts\activate
pip install -r requirements.txt
```

পাসওয়ার্ড হ্যাশ তৈরি করো (এখানে `YOUR_STRONG_PASSWORD`-এর জায়গায় নিজের পাসওয়ার্ড বসাও):
```bash
python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('YOUR_STRONG_PASSWORD'))"
```

তারপর environment variables সেট করো। `SECRET_KEY`-এর জন্য আলাদা, দীর্ঘ ও random string ব্যবহার করো। উদাহরণ (Linux/macOS/Termux):

```bash
export SECRET_KEY='একটি-লম্বা-র‍্যান্ডম-সিক্রেট'
export ADMIN_USERNAME='admin'
export ADMIN_PASSWORD_HASH='উপরের-কমান্ডে-তৈরি-হ্যাশ'
export DB_PATH='instance/messages.db'
python app.py
```

Windows PowerShell-এ `export`-এর বদলে:
```powershell
$env:SECRET_KEY="একটি-লম্বা-র‍্যান্ডম-সিক্রেট"
$env:ADMIN_USERNAME="admin"
$env:ADMIN_PASSWORD_HASH="উপরের-কমান্ডে-তৈরি-হ্যাশ"
$env:DB_PATH="instance/messages.db"
python app.py
```

ব্রাউজারে `http://127.0.0.1:5000` খুলো। Admin login: `http://127.0.0.1:5000/admin/login`।

## 3) অনলাইনে Render-এ প্রকাশ করা
1. ZIP ফাইলটি extract করো।
2. ফাইলগুলো একটি নতুন GitHub repository-তে upload করো। `.env` বা বাস্তব secret কখনো upload করবে না।
3. Render-এ login করে **New + → Blueprint** বেছে নাও এবং GitHub repository connect করো।
4. Render `render.yaml` পড়ে service তৈরি করবে। `ADMIN_PASSWORD_HASH`-এর জন্য Render Dashboard → service → Environment-এ hash বসাও।
5. Hash বানানোর জন্য নিজের কম্পিউটার/Termux-এ dependencies install করে এই কমান্ড চালাতে পারো:
   ```bash
   pip install -r requirements.txt
   python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('YOUR_STRONG_PASSWORD'))"
   ```
   তৈরি হওয়া hash-টি `ADMIN_PASSWORD_HASH`-এ বসাও। আসল পাসওয়ার্ড নয়, hash-টাই বসাবে।
6. Deploy শেষ হলে Render তোমাকে `https://...onrender.com` ধরনের ওয়েবসাইট লিংক দেবে।
7. Admin panel খুলবে `https://তোমার-সাইট.onrender.com/admin/login` দিয়ে। Username হবে `admin` (চাইলে Environment-এ বদলাতে পারো), password হবে hash বানানোর সময় যে পাসওয়ার্ড দিয়েছিলে।

## গুরুত্বপূর্ণ নিরাপত্তা ও হোস্টিং নোট
- `SECRET_KEY` এবং `ADMIN_PASSWORD_HASH` গোপন রাখবে। এগুলো কাউকে পাঠাবে না বা GitHub-এ commit করবে না।
- `render.yaml`-এ persistent disk সেট করা আছে। Render-এ persistent disk ব্যবহার করতে paid service লাগতে পারে। Deploy করার আগে Render-এর বর্তমান মূল্য ও disk availability দেখে নিও।
- Persistent disk ছাড়া SQLite ডেটা deploy/restart হলে হারিয়ে যেতে পারে। তাই মেসেজ সত্যিই সংরক্ষণ করতে persistent disk বা managed database ব্যবহার করো।
- Rate limit এখানে সহজ per-process ব্যবস্থা; একাধিক instance বা বড় ট্রাফিকের জন্য shared rate limiter লাগবে।
- এই সাইট মেসেজ গ্রহণের সময় প্রেরকের নাম সংগ্রহ করে না, তবে হোস্টিং/নেটওয়ার্ক স্তরে IP লগ থাকতে পারে। তাই একে সম্পূর্ণ ট্র্যাক-অযোগ্য বলে প্রচার করবে না।
- পাবলিক মেসেজ সাইটে abuse/spam আসতে পারে। প্রয়োজনে moderation, report option ও retention policy যোগ করো।


## ডিজাইন
- মোবাইল ও কম্পিউটারে মানানসই responsive layout, gradient header, message cards এবং Bengali-friendly typography আছে।

## পাবলিক মেসেজ ওয়াল
- মূল পেজে পাঠানো মেসেজ সবার কাছে দৃশ্যমান হবে; নতুন মেসেজ আগে দেখাবে।
- পাবলিক পেজে সর্বশেষ ২০০টি মেসেজ দেখানো হয়, Admin Panel-এ সর্বশেষ ৫০০টি।
- কোনো ব্যক্তিগত তথ্য, ফোন নম্বর, ঠিকানা বা পাসওয়ার্ড পোস্ট করতে উৎসাহিত করবে না। আপত্তিকর মেসেজ Admin Panel থেকে মুছে ফেলো।


## রেফারেন্স ডিজাইন
ওয়েবসাইটের হোম পেজটি ব্যবহারকারীর দেওয়া নমুনা ছবির মতো দুই-কলামের লেআউট, বাম পাশে মেসেজ ফর্ম ও ডান পাশে পাবলিক মেসেজ ওয়াল, গাঢ় নেভি হেডার, গোলাপি-বেগুনি অ্যাকসেন্ট এবং মোবাইল রেসপনসিভ স্টাইল অনুসরণ করে।
