import os
import sqlite3
import time
from pathlib import Path
from functools import wraps

from flask import Flask, request, redirect, url_for, render_template, session, flash, abort
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024  # 16 KB request limit
csrf = CSRFProtect(app)

ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD_HASH = os.environ.get("ADMIN_PASSWORD_HASH", "")
DB_PATH = os.environ.get("DB_PATH", "instance/messages.db")

if not app.config["SECRET_KEY"]:
    raise RuntimeError("SECRET_KEY environment variable is required.")
if not ADMIN_PASSWORD_HASH:
    raise RuntimeError(
        "ADMIN_PASSWORD_HASH is required. Generate it with: "
        "python -c \"from werkzeug.security import generate_password_hash; "
        "print(generate_password_hash('YOUR_STRONG_PASSWORD'))\""
    )

# Simple per-process submission throttle. For high traffic, use a shared rate limiter.
recent_posts = {}
RATE_LIMIT_SECONDS = 20


def connect_db():
    path = Path(DB_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with connect_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                body TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)


init_db()


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        # Honeypot field should stay empty; basic spam deterrent.
        if request.form.get("website", "").strip():
            return render_template("sent.html")

        ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()
        now = time.time()
        last = recent_posts.get(ip, 0)
        if now - last < RATE_LIMIT_SECONDS:
            flash("অনুগ্রহ করে ২০ সেকেন্ড অপেক্ষা করে আবার পাঠান।", "error")
            return redirect(url_for("home"))

        body = request.form.get("message", "").strip()
        if not body:
            flash("মেসেজ লিখে পাঠান।", "error")
            return redirect(url_for("home"))
        if len(body) > 1000:
            flash("মেসেজ সর্বোচ্চ ১০০০ অক্ষরের হতে পারবে।", "error")
            return redirect(url_for("home"))

        with connect_db() as db:
            db.execute("INSERT INTO messages (body) VALUES (?)", (body,))
        recent_posts[ip] = now
        return render_template("sent.html")

    with connect_db() as db:
        public_messages = db.execute(
            "SELECT id, body, created_at FROM messages ORDER BY id DESC LIMIT 200"
        ).fetchall()
    return render_template("home.html", public_messages=public_messages)


@app.route("/admin/login", methods=["GET", "POST"])
def login():
    if session.get("is_admin"):
        return redirect(url_for("admin"))
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, password):
            session.clear()
            session["is_admin"] = True
            return redirect(url_for("admin"))
        flash("ইউজারনেম অথবা পাসওয়ার্ড সঠিক নয়।", "error")
    return render_template("login.html")


@app.route("/admin/logout", methods=["POST"])
@admin_required
def logout():
    session.clear()
    flash("লগআউট হয়েছে।", "success")
    return redirect(url_for("login"))


@app.route("/admin")
@admin_required
def admin():
    with connect_db() as db:
        messages = db.execute(
            "SELECT id, body, created_at FROM messages ORDER BY id DESC LIMIT 500"
        ).fetchall()
    return render_template("admin.html", messages=messages)


@app.route("/admin/delete/<int:message_id>", methods=["POST"])
@admin_required
def delete_message(message_id):
    with connect_db() as db:
        db.execute("DELETE FROM messages WHERE id = ?", (message_id,))
    flash("মেসেজ মুছে ফেলা হয়েছে।", "success")
    return redirect(url_for("admin"))


@app.errorhandler(413)
def too_large(_error):
    return "অনুরোধটি অনেক বড়।", 413


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
